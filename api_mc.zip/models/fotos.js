"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fotos = void 0;
class Fotos {
}
exports.Fotos = Fotos;
