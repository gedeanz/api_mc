"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Galeria = void 0;
const core_1 = require("./core");
class Galeria extends core_1.Core {
}
exports.Galeria = Galeria;
