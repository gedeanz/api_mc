"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Podcast = void 0;
const core_1 = require("./core");
class Podcast extends core_1.Core {
}
exports.Podcast = Podcast;
