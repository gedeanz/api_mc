export class Result<T>{
    Qtd: number;
    Page: number;
    Total: number;
    Data: Array<T>;
}