"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Core = void 0;
const mongoose_1 = require("mongoose");
class Core extends mongoose_1.Document {
}
exports.Core = Core;
